from Location.models.Point import Point


class WifiData:
    def __init__(self, bssid: str, signal: str, networkName: str,
                 networkType : str = "", originPoint: Point = Point(0, 0)):
        self.networkName = networkName
        self.bssid = bssid
        self.distance = 100
        self.signal = signal
        self.networkType = networkType
        self.originPoint: Point = originPoint

    def __eq__(self, other):
        return self.bssid == other.bssid

    def __le__(self, other):
        return self.signal >= other.signal

    def __lt__(self, other):
        return self.signal > other.signal



class DistCalData:
    def __init__(self,  signal: str):
        self.siganlStrenght = signal
        self.NetworkType = "802.11ac"
        self.dataLost = 0
        self.SignalHZ = 0