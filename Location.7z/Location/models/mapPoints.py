import math

from Location.models.dataModels import Point

class special_point:
    bssid_signal_strength = {}
    point: Point

    def __init__(self, bssid_signal:{str:int}, point:Point):
        self.bssid_signal_strength = bssid_signal
        self.point = point

    def __getitem__(self, item):
        return self.bssid_signal_strength[item]

p1=special_point(
{'e8:1c:ba:28:a3:18': 80.0, '70:4c:a5:9e:fb:f1': 82.0},
        Point(2.5,3.7))



special_points = [


    ]


def getClosestPoint(bssid_signal:{str:int}):
    closest = []
    min=1000
    for point in special_points:
        sum=0
        count = 0
        for bssid in bssid_signal:
            if bssid in point.bssid_signal_strength:
               sum += abs(point[bssid]-bssid_signal[bssid])
               count+=1
               if count ==4:
                   break
        if min>sum and count>1:
            min=sum
            closest = point.point
    if min < 10:
        return closest
    return None





