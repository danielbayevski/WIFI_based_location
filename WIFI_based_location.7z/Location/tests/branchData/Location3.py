location3 = """
 
Interface name : Wi-Fi 
There are 3 networks currently visible. 

SSID 1 : BE-ALL
    Network type            : Infrastructure
    Authentication          : WPA2-Personal
    Encryption              : CCMP 
    BSSID 1                 : 70:4c:a5:20:a6:c8
         Signal             : 57%  
         Radio type         : 802.11ac
         Channel            : 36 
         Basic rates (Mbps) : 6 12 24
         Other rates (Mbps) : 9 18 36 48 54
    BSSID 2                 : 70:4c:a5:20:cb:58
         Signal             : 90%  
         Radio type         : 802.11ac
         Channel            : 36 
         Basic rates (Mbps) : 6 12 24
         Other rates (Mbps) : 9 18 36 48 54
    BSSID 3                 : 70:4c:a5:20:c9:18
         Signal             : 78%  
         Radio type         : 802.11ac
         Channel            : 36 
         Basic rates (Mbps) : 6 12 24
         Other rates (Mbps) : 9 18 36 48 54

SSID 2 : Windtech
    Network type            : Infrastructure
    Authentication          : WPA2-Personal
    Encryption              : CCMP 
    BSSID 1                 : 70:4c:a5:20:a6:c9
         Signal             : 53%  
         Radio type         : 802.11ac
         Channel            : 36 
         Basic rates (Mbps) : 6 12 24
         Other rates (Mbps) : 9 18 36 48 54

SSID 3 : Eye
    Network type            : Infrastructure
    Authentication          : WPA2-Personal
    Encryption              : CCMP 
    BSSID 1                 : d8:47:32:8e:63:16
         Signal             : 87%  
         Radio type         : 802.11ac
         Channel            : 36 
         Basic rates (Mbps) : 6 12 24
         Other rates (Mbps) : 9 18 36 48 54



Process finished with exit code 0
"""