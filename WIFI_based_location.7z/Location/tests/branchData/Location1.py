location1 = """BSSID 1                 : 70:4c:a5:20:ae:30
         Signal             : 80%
         Radio type         : 802.11ac
         Channel            : 40
         Basic rates (Mbps) : 6 12 24
         Other rates (Mbps) : 9 18 36 48 54"""
